<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Swiper demo</title>
    <!-- Link Swiper's CSS -->
    <link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/assets/css/swiper.min.css">
    <link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo bloginfo('template_url');?>/assets/css/font-awesome.min.css">
</head>
<body>
    
    
    <header>
        <div class="container">
        
<nav class="navbar navbar-default" role="navigation">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php echo bloginfo('template_url');?>/assets/images/logo.jpg" /></a>
    </div>
    <div style="padding-left: 15px;margin-left: 15px;position: relative;left: 15px;margin-bottom: 10px;" class="hidden-xs hidden-sm">
            <strong>Dicas para você organizar um evento de sucesso!</strong>
        </div>
    
    
    <div id="navbar-ex1-collapse" class="collapse navbar-collapse">
                        <?php 
                         wp_nav_menu( array(
                                        'menu'              => 'header-menu',
                                        'theme_location'    => 'header-menu',
                                        'depth'             => 2,
                                        'container'         => 'ul',
                                        'container_class'   => 'collapse navbar-collapse',                                       
                                        'menu_class'        => 'nav navbar-nav',
                                        'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                                        'walker'            => new WP_Bootstrap_Navwalker())
                                    );
                         
                        ?>
                <ul class="nav navbar-nav navbar-right visible-md visible-lg">            
            <li><a href="#"><img src="<?php echo bloginfo('template_url');?>/assets/images/logo-ticket.jpg" style="margin-top: -40px;"/></a></li>            
        </ul>         
                    </div><!-- /.navbar-collapse -->
                    
                    
    
</nav>

    </div>
    </header>