<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include(TEMPLATEPATH . '/templates/wp-bootstrap-navwalker.php');
if (function_exists('add_theme_support')) { // Adicionado no 2.9
    add_theme_support('post-thumbnails');    
    add_image_size('single-thumbnail', 350, 250,true); // imagem para página de post
}
function register_my_menu() {
  register_nav_menu('header-menu',__( 'Header Menu' ));
}
add_action( 'init', 'register_my_menu' );

function fn_template( $atts ) {
	$atts = shortcode_atts( array(
		'page' => '',
		'directory' => 'templates/html/'                
	), $atts, 'fn_template' );
   
       
       include( locate_template( $atts['directory'].$atts['page'].'.php', false, false ) ); 
               
}
add_shortcode( 'cb_template', 'fn_template' );

function wordpress_pagination() {
            global $wp_query;
 
            $big = 999999999;
 
            echo paginate_links( array(
                  'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                  'format' => '?paged=%#%',
                  'current' => max( 1, get_query_var('paged') ),
                  'total' => $wp_query->max_num_pages
            ) );
      }