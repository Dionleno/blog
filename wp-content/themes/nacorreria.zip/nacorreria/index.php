<?php
get_header();?>

 
    <?php
do_shortcode('[cb_template page="banner"]');

   $args = array(
	'post_type' => 'post',	
	'order'   => 'DESC',
);
 
 $query = new WP_Query($args);
?>
<section class="main">
    <div class="container">
        <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
             <div class="header-title">
                <h3 class="title-undercode">Recentes</h3>
            </div>
             <?php if($query->have_posts()):  ?>
            <?php while ($query->have_posts()) : $query->the_post(); 
                       
             get_template_part('loop');
             
             endwhile; ?>
            <?php endif; ?>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3" style="">
                    <?php get_sidebar(); ?>
        </div>
    </div>    
    </section>

<?php
get_footer();
?>